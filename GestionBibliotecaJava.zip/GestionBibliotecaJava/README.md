# Sistema de Gestión de Biblioteca (Java Swing)

Proyecto de escritorio para IntelliJ IDEA, desarrollado con Java 17 y Swing, con una interfaz inspirada en la imagen proporcionada.

## Estructuras de datos usadas
- **Árbol binario de búsqueda (`ArbolLibros`)**: organiza libros por código y permite búsqueda ordenada.
- **Pila (`PilaOperaciones`)**: conserva las últimas operaciones y permite deshacer la última operación registrada.
- **Cola (`ColaEspera`)**: administra estudiantes en orden de llegada para atender solicitudes.

## Ejecutar en IntelliJ IDEA
1. Descomprime el ZIP.
2. Abre la carpeta `GestionBibliotecaJava` desde IntelliJ IDEA.
3. Configura un JDK 17 o superior.
4. Espera a que IntelliJ importe el proyecto Maven (no usa dependencias externas).
5. Ejecuta `com.biblioteca.Main`.

También puedes compilar desde una terminal ubicada en la carpeta del proyecto:
```bash
mvn package
```
o compilar directamente los archivos de `src/main/java`.

## Funcionalidades
- Listado y búsqueda de libros por título o código.
- Agregar libros.
- Registrar usuarios.
- Encolar estudiantes en espera.
- Prestar libros al siguiente estudiante de la cola.
- Registrar devoluciones.
- Historial reciente y acción de deshacer la última operación de historial.

## Datos de demostración
El programa inicia con libros, usuarios y estudiantes en espera de ejemplo. Los datos se mantienen en memoria y se reinician al cerrar la aplicación.
