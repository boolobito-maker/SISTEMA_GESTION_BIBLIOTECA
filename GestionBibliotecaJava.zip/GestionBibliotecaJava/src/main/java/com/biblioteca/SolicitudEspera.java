package com.biblioteca;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class SolicitudEspera {
    private final Usuario usuario;
    private final String libroSolicitado;
    private final LocalTime hora = LocalTime.now();
    public SolicitudEspera(Usuario usuario, String libroSolicitado) {
        this.usuario = usuario; this.libroSolicitado = libroSolicitado;
    }
    public Usuario getUsuario() { return usuario; }
    public String getLibroSolicitado() { return libroSolicitado; }
    public String getHoraTexto() { return hora.format(DateTimeFormatter.ofPattern("HH:mm")); }
}
