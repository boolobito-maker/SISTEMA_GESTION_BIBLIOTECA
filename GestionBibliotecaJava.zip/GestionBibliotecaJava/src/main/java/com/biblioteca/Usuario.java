package com.biblioteca;

public class Usuario {
    private final String codigo;
    private final String nombre;
    private final String carrera;

    public Usuario(String codigo, String nombre, String carrera) {
        this.codigo = codigo; this.nombre = nombre; this.carrera = carrera;
    }
    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public String getCarrera() { return carrera; }
}
