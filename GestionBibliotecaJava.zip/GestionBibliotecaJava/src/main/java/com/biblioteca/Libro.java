package com.biblioteca;

public class Libro {
    private final String codigo;
    private String titulo;
    private String autor;
    private String categoria;
    private boolean disponible = true;

    public Libro(String codigo, String titulo, String autor, String categoria) {
        this.codigo = codigo; this.titulo = titulo; this.autor = autor; this.categoria = categoria;
    }
    public String getCodigo() { return codigo; }
    public String getTitulo() { return titulo; }
    public String getAutor() { return autor; }
    public String getCategoria() { return categoria; }
    public boolean isDisponible() { return disponible; }
    public void setDisponible(boolean disponible) { this.disponible = disponible; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    @Override public String toString() { return codigo + " - " + titulo; }
}
