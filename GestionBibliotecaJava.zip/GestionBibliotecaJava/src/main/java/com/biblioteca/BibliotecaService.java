package com.biblioteca;

import java.util.ArrayList;
import java.util.List;

public class BibliotecaService {
    private final ArbolLibros libros = new ArbolLibros();
    private final List<Usuario> usuarios = new ArrayList<>();
    private final ColaEspera espera = new ColaEspera();
    private final PilaOperaciones operaciones = new PilaOperaciones();

    public BibliotecaService() { cargarDatosDemo(); }
    private void cargarDatosDemo() {
        libros.insertar(new Libro("L001","Clean Code","Robert C. Martin","Programación"));
        libros.insertar(new Libro("L002","Introducción a Java","Herbert Schildt","Programación"));
        libros.insertar(new Libro("L003","Estructuras de Datos","Mark Allen Weiss","Informática"));
        libros.insertar(new Libro("L004","Redes de Computadoras","Andrew Tanenbaum","Redes"));
        libros.insertar(new Libro("L005","Base de Datos","Silberschatz","Bases de Datos"));
        usuarios.add(new Usuario("U001","Ana López","Ingeniería de Software"));
        usuarios.add(new Usuario("U002","Luis Rojas","Ingeniería de Software"));
        usuarios.add(new Usuario("U003","Carla Mamani","Ingeniería Civil"));
        usuarios.add(new Usuario("U004","Diego Quispe","Ingeniería de Sistemas"));
        usuarios.add(new Usuario("U005","Mely Quispe","Ingeniería de Software"));
        espera.encolar(new SolicitudEspera(usuarios.get(0),"Clean Code"));
        espera.encolar(new SolicitudEspera(usuarios.get(1),"Estructuras de Datos"));
        espera.encolar(new SolicitudEspera(usuarios.get(2),"Redes de Computadoras"));
        espera.encolar(new SolicitudEspera(usuarios.get(3),"Base de Datos"));
    }
    public List<Libro> getLibros() { return libros.listar(); }
    public List<Usuario> getUsuarios() { return new ArrayList<>(usuarios); }
    public List<SolicitudEspera> getEspera() { return espera.listar(); }
    public List<Operacion> getOperaciones() { return operaciones.recientes(8); }
    public Libro buscarLibro(String texto) {
        Libro porCodigo = libros.buscar(texto.trim());
        if (porCodigo != null) return porCodigo;
        for (Libro l : libros.listar()) if (l.getTitulo().toLowerCase().contains(texto.toLowerCase())) return l;
        return null;
    }
    public void agregarLibro(Libro l) { libros.insertar(l); registrar("Registro de libro", l.getTitulo()); }
    public void agregarUsuario(Usuario u) { usuarios.add(u); registrar("Registro de usuario", u.getNombre()); }
    public void agregarAEspera(Usuario u, String libro) { espera.encolar(new SolicitudEspera(u, libro)); registrar("Cola de espera", u.getNombre() + " - " + libro); }
    public String prestarSiguiente() {
        SolicitudEspera s = espera.desencolar();
        if (s == null) return "No hay estudiantes en espera.";
        Libro l = buscarLibro(s.getLibroSolicitado());
        if (l == null) l = buscarLibro(s.getLibroSolicitado());
        if (l != null && l.isDisponible()) {
            l.setDisponible(false); registrar("Préstamo", l.getTitulo() + " → " + s.getUsuario().getNombre());
            return "Préstamo registrado: " + l.getTitulo() + " para " + s.getUsuario().getNombre() + ".";
        }
        return "Se atendió a " + s.getUsuario().getNombre() + ", pero el libro no existe o no está disponible.";
    }
    public String devolver(String codigo) {
        Libro l = libros.buscar(codigo.trim());
        if (l == null) return "No se encontró un libro con ese código.";
        if (l.isDisponible()) return "El libro ya figura como disponible.";
        l.setDisponible(true); registrar("Devolución", l.getTitulo());
        return "Devolución registrada: " + l.getTitulo() + ".";
    }
    public Operacion deshacerUltima() {
        Operacion op = operaciones.desapilar();
        if (op != null) registrar("Deshacer", op.getTipo() + " - " + op.getDetalle());
        return op;
    }
    private void registrar(String tipo, String detalle) { operaciones.apilar(new Operacion(tipo, detalle)); }
}
