package com.biblioteca;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class BibliotecaFrame extends JFrame {
    private final BibliotecaService service = new BibliotecaService();
    private final Color azul = new Color(35, 91, 164);
    private final Color fondo = new Color(243, 247, 253);
    private final DefaultTableModel librosModel = model("Código","Título","Autor","Categoría","Estado");
    private final DefaultTableModel esperaModel = model("N°","Nombre","Libro solicitado","Hora");
    private final DefaultTableModel opsModel = model("N°","Operación","Libro / detalle","Fecha / Hora");
    private final DefaultTableModel usuariosModel = model("Código","Nombre","Carrera");
    private final JTable librosTabla = new JTable(librosModel);
    private final JTable esperaTabla = new JTable(esperaModel);
    private final JTable opsTabla = new JTable(opsModel);
    private final JTable usuariosTabla = new JTable(usuariosModel);
    private final JTextField buscar = new JTextField();

    public BibliotecaFrame() {
        setTitle("Sistema de Gestión de Biblioteca");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 730); setMinimumSize(new Dimension(900, 620));
        setLocationRelativeTo(null);
        getContentPane().setBackground(fondo);
        setLayout(new BorderLayout(10,10));
        add(crearMenu(), BorderLayout.WEST);
        JPanel contenido = new JPanel(new BorderLayout(10,10));
        contenido.setOpaque(false); contenido.setBorder(new EmptyBorder(12,0,12,12));
        contenido.add(cabecera(), BorderLayout.NORTH);
        JPanel grid = new JPanel(new GridLayout(2,2,12,12)); grid.setOpaque(false);
        grid.add(panelLibros()); grid.add(panelEspera()); grid.add(panelOperaciones()); grid.add(panelUsuarios());
        contenido.add(grid, BorderLayout.CENTER); add(contenido, BorderLayout.CENTER);
        refrescar();
    }
    private static DefaultTableModel model(String... cols) {
        return new DefaultTableModel(cols,0) { @Override public boolean isCellEditable(int r,int c){return false;} };
    }
    private JPanel crearMenu() {
        JPanel menu = new JPanel(); menu.setPreferredSize(new Dimension(150,0));
        menu.setBackground(new Color(230,239,252)); menu.setLayout(new BoxLayout(menu,BoxLayout.Y_AXIS));
        JLabel marca = new JLabel("  ◈  BIBLIOTECA"); marca.setForeground(azul); marca.setFont(new Font("SansSerif",Font.BOLD,15));
        marca.setBorder(new EmptyBorder(20,8,24,4)); menu.add(marca);
        String[] opciones={"⌂   Inicio","▣   Libros","▤   Préstamos","↶   Devoluciones","♟   Usuarios"};
        for (String op: opciones) {
            JButton b=new JButton(op); b.setHorizontalAlignment(SwingConstants.LEFT); b.setMaximumSize(new Dimension(145,42));
            b.setFocusPainted(false); b.setBorder(new EmptyBorder(10,12,10,4)); b.setBackground(op.contains("Inicio")?new Color(74,143,235):new Color(230,239,252));
            b.setForeground(op.contains("Inicio")?Color.WHITE:new Color(35,66,111)); b.setFont(new Font("SansSerif",Font.PLAIN,13));
            b.addActionListener(e -> {
                if(op.contains("Libros")) buscar.requestFocus();
                else if(op.contains("Préstamos")) prestar();
                else if(op.contains("Devoluciones")) devolver();
                else if(op.contains("Usuarios")) agregarUsuario();
            });
            menu.add(b);
        }
        menu.add(Box.createVerticalGlue()); return menu;
    }
    private JPanel cabecera() {
        JPanel p=new JPanel(new BorderLayout()); p.setBackground(new Color(230,240,255));
        p.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(207,222,244)),new EmptyBorder(12,16,12,16)));
        JLabel icon=new JLabel("📖"); icon.setFont(new Font("SansSerif",Font.PLAIN,30));
        JLabel titulo=new JLabel("<html><b>Administración de Biblioteca</b><br><span style='font-size:10px'>Organiza y administra los libros, usuarios y préstamos de la biblioteca.</span></html>");
        titulo.setForeground(new Color(25,62,112)); titulo.setFont(new Font("SansSerif",Font.PLAIN,18));
        p.add(icon,BorderLayout.WEST); p.add(titulo,BorderLayout.CENTER); return p;
    }
    private JPanel tarjeta(String titulo, String icono, Color color, JComponent contenido, JButton accion) {
        JPanel p=new JPanel(new BorderLayout(5,8)); p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(211,222,238)),new EmptyBorder(8,9,8,9)));
        JPanel top=new JPanel(new BorderLayout()); top.setOpaque(false);
        JLabel l=new JLabel(icono+"  "+titulo); l.setForeground(color); l.setFont(new Font("SansSerif",Font.BOLD,14)); top.add(l,BorderLayout.WEST);
        if(accion!=null) top.add(accion,BorderLayout.EAST);
        p.add(top,BorderLayout.NORTH); p.add(contenido,BorderLayout.CENTER); return p;
    }
    private JButton boton(String txt, Color c, Runnable accion) {
        JButton b=new JButton(txt); b.setBackground(c); b.setForeground(Color.WHITE); b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(7,10,7,10)); b.addActionListener(e->accion.run()); return b;
    }
    private JPanel panelLibros() {
        JPanel body=new JPanel(new BorderLayout(6,7)); body.setOpaque(false);
        JPanel bus=new JPanel(new BorderLayout(5,0)); bus.setOpaque(false);
        buscar.setToolTipText("Buscar por título o código"); buscar.setPreferredSize(new Dimension(150,28));
        JButton btnBuscar=boton("⌕",new Color(65,137,225),()->filtrarLibros());
        JButton agregar=boton("+ Agregar",new Color(65,137,225),()->agregarLibro());
        bus.add(buscar,BorderLayout.CENTER); bus.add(btnBuscar,BorderLayout.EAST);
        body.add(bus,BorderLayout.NORTH); body.add(new JScrollPane(librosTabla),BorderLayout.CENTER);
        buscar.addActionListener(e->filtrarLibros());
        return tarjeta("Libros","▣",azul,body,agregar);
    }
    private JPanel panelEspera() {
        JButton agregar=boton("+ Agregar",new Color(235,143,53),()->agregarEspera());
        return tarjeta("Estudiantes en espera","♟",new Color(191,105,28),new JScrollPane(esperaTabla),agregar);
    }
    private JPanel panelOperaciones() {
        JButton deshacer=boton("↶ Deshacer",new Color(123,111,205),()->{
            Operacion op=service.deshacerUltima();
            JOptionPane.showMessageDialog(this,op==null?"No hay operaciones para deshacer.":"Se retiró del historial: "+op.getTipo()+".\nNota: esta acción retira la entrada del historial; no revierte cambios de datos.");
            refrescar();
        });
        JPanel body=new JPanel(new BorderLayout(4,5)); body.setOpaque(false); body.add(new JScrollPane(opsTabla),BorderLayout.CENTER);
        JLabel nota=new JLabel("<html>ⓘ Se guardan las últimas operaciones realizadas<br>para poder deshacerlas del historial.</html>");
        nota.setForeground(new Color(88,92,160)); nota.setBorder(new EmptyBorder(5,5,5,5)); body.add(nota,BorderLayout.SOUTH);
        return tarjeta("Últimas operaciones","◴",new Color(104,91,196),body,deshacer);
    }
    private JPanel panelUsuarios() {
        JButton agregar=boton("+ Registrar",new Color(42,145,111),()->agregarUsuario());
        return tarjeta("Usuarios registrados","♟",new Color(42,125,96),new JScrollPane(usuariosTabla),agregar);
    }
    private void filtrarLibros() {
        String q=buscar.getText().trim().toLowerCase(); librosModel.setRowCount(0);
        for(Libro l:service.getLibros()) if(q.isEmpty()||l.getCodigo().toLowerCase().contains(q)||l.getTitulo().toLowerCase().contains(q))
            librosModel.addRow(new Object[]{l.getCodigo(),l.getTitulo(),l.getAutor(),l.getCategoria(),l.isDisponible()?"Disponible":"Prestado"});
    }
    private void refrescar() {
        filtrarLibros(); esperaModel.setRowCount(0); int i=1;
        for(SolicitudEspera s:service.getEspera()) esperaModel.addRow(new Object[]{i++,s.getUsuario().getNombre(),s.getLibroSolicitado(),s.getHoraTexto()});
        opsModel.setRowCount(0); i=1;
        for(Operacion o:service.getOperaciones()) opsModel.addRow(new Object[]{i++,o.getTipo(),o.getDetalle(),o.getFechaTexto()});
        usuariosModel.setRowCount(0);
        for(Usuario u:service.getUsuarios()) usuariosModel.addRow(new Object[]{u.getCodigo(),u.getNombre(),u.getCarrera()});
    }
    private void agregarLibro() {
        JTextField codigo=new JTextField(),titulo=new JTextField(),autor=new JTextField(),cat=new JTextField();
        Object[] campos={"Código (ej. L006):",codigo,"Título:",titulo,"Autor:",autor,"Categoría:",cat};
        if(JOptionPane.showConfirmDialog(this,campos,"Agregar libro",JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION) {
            if(codigo.getText().isBlank()||titulo.getText().isBlank()){mensaje("Código y título son obligatorios.");return;}
            if(service.buscarLibro(codigo.getText())!=null){mensaje("Ya existe un libro con ese código o título coincidente.");return;}
            service.agregarLibro(new Libro(codigo.getText().trim(),titulo.getText().trim(),autor.getText().trim(),cat.getText().trim())); refrescar();
        }
    }
    private void agregarUsuario() {
        JTextField codigo=new JTextField(),nombre=new JTextField(),carrera=new JTextField();
        Object[] campos={"Código (ej. U006):",codigo,"Nombre:",nombre,"Carrera:",carrera};
        if(JOptionPane.showConfirmDialog(this,campos,"Registrar usuario",JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION) {
            if(codigo.getText().isBlank()||nombre.getText().isBlank()){mensaje("Código y nombre son obligatorios.");return;}
            for(Usuario u:service.getUsuarios()) if(u.getCodigo().equalsIgnoreCase(codigo.getText().trim())){mensaje("Ese código de usuario ya existe.");return;}
            service.agregarUsuario(new Usuario(codigo.getText().trim(),nombre.getText().trim(),carrera.getText().trim())); refrescar();
        }
    }
    private void agregarEspera() {
        List<Usuario> usuarios=service.getUsuarios();
        if(usuarios.isEmpty()){mensaje("Primero registra un usuario.");return;}
        JComboBox<Usuario> combo=new JComboBox<>(usuarios.toArray(new Usuario[0]));
        combo.setRenderer((list,value,index,selected,focus)->new JLabel(value==null?"":value.getNombre()+" ("+value.getCodigo()+")"));
        JTextField libro=new JTextField();
        Object[] campos={"Estudiante:",combo,"Libro solicitado (título o código):",libro};
        if(JOptionPane.showConfirmDialog(this,campos,"Agregar a la cola de espera",JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION) {
            Usuario u=(Usuario)combo.getSelectedItem();
            if(u!=null&&!libro.getText().isBlank()){service.agregarAEspera(u,libro.getText().trim());refrescar();}
        }
    }
    private void prestar() {
        int ok=JOptionPane.showConfirmDialog(this,"¿Atender al siguiente estudiante de la cola?","Registrar préstamo",JOptionPane.YES_NO_OPTION);
        if(ok==JOptionPane.YES_OPTION){mensaje(service.prestarSiguiente());refrescar();}
    }
    private void devolver() {
        String codigo=JOptionPane.showInputDialog(this,"Código del libro a devolver (ej. L001):","Devolución",JOptionPane.QUESTION_MESSAGE);
        if(codigo!=null&&!codigo.isBlank()){mensaje(service.devolver(codigo));refrescar();}
    }
    private void mensaje(String s){JOptionPane.showMessageDialog(this,s,"Sistema de biblioteca",JOptionPane.INFORMATION_MESSAGE);}
}
