package com.biblioteca;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Operacion {
    private final String tipo, detalle;
    private final LocalDateTime fecha = LocalDateTime.now();
    public Operacion(String tipo, String detalle) { this.tipo = tipo; this.detalle = detalle; }
    public String getTipo() { return tipo; }
    public String getDetalle() { return detalle; }
    public String getFechaTexto() { return fecha.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")); }
}
