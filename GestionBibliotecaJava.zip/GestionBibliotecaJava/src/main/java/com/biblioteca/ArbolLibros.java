package com.biblioteca;

/** Árbol binario de búsqueda ordenado por código de libro. */
public class ArbolLibros {
    private static class Nodo {
        Libro libro; Nodo izquierdo, derecho;
        Nodo(Libro libro) { this.libro = libro; }
    }
    private Nodo raiz;

    public void insertar(Libro libro) { raiz = insertar(raiz, libro); }
    private Nodo insertar(Nodo nodo, Libro libro) {
        if (nodo == null) return new Nodo(libro);
        int cmp = libro.getCodigo().compareToIgnoreCase(nodo.libro.getCodigo());
        if (cmp < 0) nodo.izquierdo = insertar(nodo.izquierdo, libro);
        else if (cmp > 0) nodo.derecho = insertar(nodo.derecho, libro);
        else nodo.libro = libro;
        return nodo;
    }
    public Libro buscar(String codigo) {
        Nodo actual = raiz;
        while (actual != null) {
            int cmp = codigo.compareToIgnoreCase(actual.libro.getCodigo());
            if (cmp == 0) return actual.libro;
            actual = cmp < 0 ? actual.izquierdo : actual.derecho;
        }
        return null;
    }
    public java.util.List<Libro> listar() {
        java.util.List<Libro> resultado = new java.util.ArrayList<>();
        enOrden(raiz, resultado); return resultado;
    }
    private void enOrden(Nodo nodo, java.util.List<Libro> lista) {
        if (nodo == null) return;
        enOrden(nodo.izquierdo, lista); lista.add(nodo.libro); enOrden(nodo.derecho, lista);
    }
}
