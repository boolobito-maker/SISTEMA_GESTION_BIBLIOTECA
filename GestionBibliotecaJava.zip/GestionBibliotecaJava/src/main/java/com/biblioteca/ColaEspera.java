package com.biblioteca;

import java.util.ArrayDeque;
import java.util.Queue;

/** Cola FIFO para atender solicitudes por orden de llegada. */
public class ColaEspera {
    private final Queue<SolicitudEspera> cola = new ArrayDeque<>();
    public void encolar(SolicitudEspera solicitud) { cola.offer(solicitud); }
    public SolicitudEspera desencolar() { return cola.poll(); }
    public java.util.List<SolicitudEspera> listar() { return new java.util.ArrayList<>(cola); }
    public boolean estaVacia() { return cola.isEmpty(); }
}
