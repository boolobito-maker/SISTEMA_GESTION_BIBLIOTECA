package com.biblioteca;

import java.util.ArrayDeque;
import java.util.Deque;

/** Pila LIFO: la última operación registrada aparece primero. */
public class PilaOperaciones {
    private final Deque<Operacion> pila = new ArrayDeque<>();
    public void apilar(Operacion op) { pila.push(op); }
    public Operacion desapilar() { return pila.poll(); }
    public java.util.List<Operacion> recientes(int limite) {
        java.util.List<Operacion> lista = new java.util.ArrayList<>();
        int i = 0;
        for (Operacion op : pila) { if (i++ >= limite) break; lista.add(op); }
        return lista;
    }
    public boolean estaVacia() { return pila.isEmpty(); }
}
